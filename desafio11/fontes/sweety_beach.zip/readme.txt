Hello,

Thank you for downloading Sweety Beach.

NOTE: This font is FREE 100% FOR PERSONAL USE ONLY! But any donations are very appreciated. 

Paypal account for donation: https://paypal.me/amalyusup


Link to purchase full version and commercial license :

-> https://www.creativefabrica.com/product/sweety-beach/ref/1492663/


Browse More Font:
-> https://www.creativefabrica.com/designer/senihujan/ref/1492663


If you need a custom license please contact us at 
senihujan@gmail.com


Follow our Instagram for update: @senihujan

Thanks,
Senihujan Studio